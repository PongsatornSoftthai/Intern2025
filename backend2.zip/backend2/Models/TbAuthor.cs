﻿using System;
using System.Collections.Generic;

namespace backend2.Models;

public partial class TbAuthor
{
    public int NAuthorId { get; set; }

    public string? SAuthorName { get; set; }
}
