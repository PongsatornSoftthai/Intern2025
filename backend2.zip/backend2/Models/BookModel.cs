﻿namespace backend2.Models.BookModel
{
    public class BookData
    {
        public int nID { get; set; }
    }

}
